import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

const HomeScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Welcome To Awais App</Text>
      <Button
        title="Login To Go To Account"
        onPress={() => navigation.navigate('Login')}
        style={styles.button}
      />
      <Button
        title="Sign Up To Create Account"
        onPress={() => navigation.navigate('SignUp')}
        style={styles.button}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'lightgreen',
  },
  title: {
    fontSize: 24,
    marginBottom: 16,
    fontWeight: 'bold',
    color: 'red',
  },
  button: {
    marginTop: 20,
  },
});

export default HomeScreen;